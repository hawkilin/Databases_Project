# DataBases_Project
This is the Databases project repository for Tristan Harville and Lindsay Hawkins. This is a web app used for plant care!
